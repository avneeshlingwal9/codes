#include <iostream>
#include "my.h"
using namespace std ;
int main(){
    cout << "Name :- Anushka Negi " << endl ;
    cout << "Section:- G1 " << endl; 
    cout << "Roll No. :- 11 " << endl ; 
    int val = 0 ;
    val = sumofNumbers(a,b);
    cout << "Value of sum:- " << val << endl ;  
}
