a = int(input("Enter a number : - "))
b = int(input("Enter another number : - "))
print("Right bitwise shift of first number by the second number : - " , a>>b)
print("Left bitwise shift of the first number by second number : - " , a<<b)